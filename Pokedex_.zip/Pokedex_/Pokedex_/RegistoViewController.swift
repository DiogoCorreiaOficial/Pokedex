//
//  RegistoViewController.swift
//  Pokedex_
//
//  Created by Diogo Correia on 01/07/2019.
//  Copyright © 2019 Diogo Correia. All rights reserved.
//

import UIKit

var imagemregisto: UIImage?

class RegistoViewController: UIViewController , UINavigationControllerDelegate, UIImagePickerControllerDelegate   {

    @IBOutlet weak var textNome: UITextField!
    @IBOutlet weak var textHp: UITextField!
    @IBOutlet weak var textXp: UITextField!
    @IBOutlet weak var textDescri: UITextField!
    @IBOutlet weak var textListAtaq: UITextField!
    @IBOutlet weak var textTipo: UITextField!
    @IBOutlet weak var textsubTipo: UITextField!
    @IBOutlet weak var textNivelForc: UITextField!
    @IBOutlet weak var textEvolucao: UITextField!
    
    
    
    
    var nome:String?
    var descricao:String?
    var listatack:String?
    var tipo:String?
    var subtipo:String?
    var evolucao:String?


    
    
    
    //Acção
    @IBAction func btnGuardar(_ sender: Any) {
        
        if(imagemview.image	 == nil){
            
            
            
            
            showToast(controller: self, message : "É Obrigatorio Imagem do Pokemon", seconds: 2.0)

            
            
            
        }else{
            
            
            nome = textNome.text
            let xp: Int = Int(textXp.text ?? "0") ?? 0
            let hp: Int = Int(textHp.text ?? "0") ?? 0
            descricao = textDescri.text
            listatack = textListAtaq.text
            tipo = textTipo.text
            subtipo = textsubTipo.text
            let nivelforce: Int = Int(textNivelForc.text ?? "0") ?? 0
            evolucao =  textEvolucao.text
            imagemregisto = imagemview.image
            //testar a ver se recebe valores
            /*
             print(nome)
             print(hp)
             print(xp)
             print(descricao!)
             print(listatack!)
             print(tipo!)
             print(subtipo!)
             print(nivelforce)
             */
            
            
            
            Lista.append(Pokemon(nome: nome!, xp: xp, hp: hp, descricao: descricao!, attacklist: listatack!, tipo: tipo!, subtipo: subtipo!, forca: nivelforce, evolucoes: evolucao!, imagem: imagemregisto!))
            
            
            
            _ = navigationController?.popViewController(animated: true)
            showToast(controller: self, message : "Guardado Com Sucesso", seconds: 2.0) 
            
            //testar a ver se esta a gravar
            //print(Lista.count)
        }
        
        
        
        
        
    
    }
    
    
    
    @IBOutlet weak var imagemview: UIImageView!
    
    @IBAction func selecionarimagem(_ sender: UIButton) {
        
        let imagecontroller = UIImagePickerController()
        imagecontroller.delegate = self
        imagecontroller.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(imagecontroller, animated: true, completion: nil)
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       // imagemregisto = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        imagemview.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
        
        
    }
    
    
    func showToast(controller: UIViewController, message : String, seconds: Double) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.view.backgroundColor = UIColor.red
        alert.view.alpha = 0.6
        alert.view.layer.cornerRadius = 30
        
        controller.present(alert, animated: true)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            alert.dismiss(animated: true)
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let ToolBar = UIToolbar()
        ToolBar.sizeToFit()
        let feitoButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.done, target: self , action: #selector(self.doneClicked))
        
        ToolBar.setItems([feitoButton], animated: false)
        
        
        textXp.inputAccessoryView = ToolBar
        textNome.inputAccessoryView = ToolBar
        
        textHp.inputAccessoryView = ToolBar
        
        textDescri.inputAccessoryView = ToolBar
        textListAtaq.inputAccessoryView = ToolBar
        textTipo.inputAccessoryView = ToolBar
        textsubTipo.inputAccessoryView = ToolBar
        textNivelForc.inputAccessoryView = ToolBar
        textEvolucao.inputAccessoryView = ToolBar

        
      
    }
    

    
    @objc func doneClicked(){
        
        view.endEditing(true)
        
        
    }
    
    
    
    
    

}
