//
//  DetailViewController.swift
//  Pokedex_
//
//  Created by Diogo Correia on 26/06/2019.
//  Copyright © 2019 Diogo Correia. All rights reserved.
//

import UIKit


func getPokemon(nome: String) -> Pokemon? {
    var aux:Pokemon?
    Lista.forEach { elem in
        if elem.Nome == nome {
            aux = elem
        }
    }
    return aux
}

class DetailViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblHp: UILabel!
    @IBOutlet weak var lblXp: UILabel!
    @IBOutlet weak var lblDisc: UILabel!
    @IBOutlet weak var lblListaAtaque: UILabel!
    @IBOutlet weak var lbltipo: UILabel!
    @IBOutlet weak var lblSubTipo: UILabel!
    @IBOutlet weak var lblforca: UILabel!
    
    @IBOutlet weak var lblEvo: UILabel!
    
    
    
    
    var nomeDt = ""
    var hpDt = 0
    var xpDt = 0
    var discDt = ""
    var listDt = ""
    var tipoDt = ""
    var subtipoDt = ""
    var forca = 0
    var evol = ""
    
    
    
    
    
    
    
    
    
    
    var image = UIImage()
    var name = ""
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        lbl.text = "Escolhes-te o \(name)"
        lblHp.text = "\(getPokemon(nome: name)?.Hp ?? 0)"
        lblXp.text = "\(getPokemon(nome: name)?.Força ?? 0)"
        lblDisc.text = "\(getPokemon(nome: name)?.Descricao ?? "")"
        lblListaAtaque.text = "\(getPokemon(nome: name)?.AttackList ?? "")"
        lbltipo.text = "\(getPokemon(nome: name)?.Tipo ?? "")"
        lblSubTipo.text = "\(getPokemon(nome: name)?.SubTipo ?? "")"
        lblforca.text = "\(getPokemon(nome: name)?.Força ?? 0)"
        lblEvo.text = "\(getPokemon(nome: name)?.Evolucoes ?? "")"
        
        
        
        
        img.image = image
        
        
       
        
        
        
        
        
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    
    
    
    @IBAction func OnClickBotao(_ sender: Any) {
    }
    
    

}
