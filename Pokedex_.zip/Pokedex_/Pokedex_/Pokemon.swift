//
//  Pokemon.swift
//  Pokedex_
//
//  Created by Diogo Correia on 27/06/2019.
//  Copyright © 2019 Diogo Correia. All rights reserved.
//

import Foundation
import UIKit

class Pokemon {
    var Nome: String
    var Xp: Int
    var Hp: Int
    var Descricao: String
    var AttackList: String // Alterar Futuramente
    var Tipo: String
    var SubTipo: String
    var Força: Int
    var Evolucoes: String //Alterar
    var Imagem: UIImage //Alterar
    
    init(nome: String, xp: Int, hp: Int, descricao: String, attacklist: String, tipo: String, subtipo: String, forca: Int, evolucoes: String, imagem: UIImage) {
        self.Nome = nome
        self.Xp = xp
        self.Hp = hp
        self.Descricao = descricao
        self.AttackList = attacklist
        self.Tipo = tipo
        self.SubTipo = subtipo
        self.Força = forca
        self.Evolucoes = evolucoes
        self.Imagem = imagem
    }
    
    
    
    
}
