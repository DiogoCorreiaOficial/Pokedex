///Users/correia/Desktop/Pokedex_/Pokedex_/ViewController.swift
//  CellTableViewCell.swift
//  Pokedex_
//
//  Created by Diogo Correia on 26/06/2019.
//  Copyright © 2019 Diogo Correia. All rights reserved.
//

import UIKit

class CellTableViewCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
 
        // Configure the view for the selected state
    }

}
