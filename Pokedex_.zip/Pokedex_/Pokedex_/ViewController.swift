//
//  ViewController.swift
//  Pokedex_
//
//  Created by Diogo Correia on 26/06/2019.
//  Copyright © 2019 Diogo Correia. All rights reserved.
//

import UIKit
    var Lista = [Pokemon]()


class ViewController: UIViewController{

    
    
    
    
    
    @IBOutlet weak var TableViewController: UITableView!
    
    
    @IBOutlet weak var TableView: UITableView!

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Adicionar", style: .plain, target: self, action: #selector(BtnDetails))
        
        
        /*
        
        Lista.append(Pokemon(nome: "charmander", xp: 10, hp: 10, descricao: "Forte", attacklist: "Bolas de fogo", tipo: "Fogo", subtipo: "Não tem", forca: 30, evolucoes: "tem", imagem: imagemregisto!))
        
        
        Lista.append(Pokemon(nome: "squirtle", xp: 10, hp: 20, descricao: "Meio-Forte", attacklist: "Jato de água", tipo: "Agua", subtipo: "Não tem", forca: 20, evolucoes: "tem", imagem: imagemregisto!))
        
        Lista.append(Pokemon(nome: "greninja", xp: 10, hp: 30, descricao: "Meio-Forte", attacklist: "Corte das Trevas", tipo: "Ninja", subtipo: "venenoso", forca: 20, evolucoes: "tem", imagem: imagemregisto!))
        
        Lista.append(Pokemon(nome: "Ratata", xp: 10, hp: 40, descricao: "fraco", attacklist: "Mordida", tipo: "erva", subtipo: "Não tem", forca: 20, evolucoes: "tem", imagem: imagemregisto!))
        */
        
        
        
        
        //let pokemonCharmander = getPokemon(nome: "charmander" )?.Nome ?? "Não existe"
        
       // print(pokemonCharmander)
        
        // self.TableView.reloadData()
        
    }
    
   
    
    override func viewDidAppear(_ animated: Bool) {
        self.TableView.reloadData()
    }
    
    
    
    /*
    override func  ViewDidAppear(_ animated: Bool) {
        self.TableView.reloadData()
    }
    */
    
    
 
    @objc
    func BtnDetails() {
        guard let view = self.storyboard?.instantiateViewController(withIdentifier: "RegistoViewController") as? RegistoViewController else {
            return
        }
        
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    
    func getPokemon(nome: String) -> Pokemon? {
        var aux:Pokemon?
       Lista.forEach { elem in
            if elem.Nome == nome {
                aux = elem
            }
        }
        return aux
    }
    
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    

}


extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Lista.count
        
        
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CellTableViewCell
        
        cell?.lbl.text = Lista [indexPath.row].Nome

        cell?.img.image = Lista[indexPath.row].Imagem
        return cell!
        
    }
    
    
    
    //Metodo Delete		
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete
        {
        Lista.remove(at: indexPath.row)
            self.TableView.reloadData()
            
            
         }
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       let vc = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
         vc?.image = Lista[indexPath.row].Imagem
        vc?.name = Lista [indexPath.row].Nome
        self.navigationController?.pushViewController(vc!, animated: true)
        TableView.reloadData()
       
        
        
    }
    
    
}
